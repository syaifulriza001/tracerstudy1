# Tracer-Study-IT-USU
Web-based platform to collect data and feedback from University of Muhammadiyah Jakarta, especially Information Technology program, to track their professional achievements and gain invaluable insight of the university's performance and quality.
